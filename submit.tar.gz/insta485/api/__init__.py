"""Insta485 REST API."""

from insta485.api.v1 import api_get_resource_urls
from insta485.api.v1 import api_get_newest_posts
from insta485.api.v1 import api_get_post
from insta485.api.v1 import api_update_likes
from insta485.api.v1 import api_delete_likes
from insta485.api.v1 import api_add_comment
from insta485.api.v1 import api_del_comment
